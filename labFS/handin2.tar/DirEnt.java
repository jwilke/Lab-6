/*
 * DirEnt -- fields of a directory entry. Feel free
 * to modify this class as desired.
 *
 * You must follow the coding standards distributed
 * on the class web page.
 *
 * (C) 2007 Mike Dahlin
 *
 */
public class DirEnt{
  public final static int MAX_NAME_LEN_CHAR = 16;
  private boolean valid;
  private int inum;
  private char name[] = new char[MAX_NAME_LEN_CHAR];

  //
  // Feel free to modify DirEnt as desired
  //
}
